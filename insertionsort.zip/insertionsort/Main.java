package insertion_sort;

import java.util.Arrays;

public class Main {
    public static void main(String[] args) {
        int[] arr = {5, 2, 9, 1, 5, 6};

        // Testing InsertionSort with Swap Method
        InsertionSort insertionSort = new InsertionSort();

        // Ascending order
        int[] arrAsc = Arrays.copyOf(arr, arr.length);
        insertionSort.insertionSortAsc(arrAsc);
        System.out.println("InsertionSort (Swap) Ascending: " + Arrays.toString(arrAsc));

        // Descending order
        int[] arrDesc = Arrays.copyOf(arr, arr.length);
        insertionSort.insertionSortDesc(arrDesc);
        System.out.println("InsertionSort (Swap) Descending: " + Arrays.toString(arrDesc));

        // Testing InsertionSortOP with Replacement Method
        InsertionSortOP insertionSortOP = new InsertionSortOP();

        // Ascending order
        int[] arrOPAsc = Arrays.copyOf(arr, arr.length);
        insertionSortOP.insertionSortOPAsc(arrOPAsc);
        System.out.println("InsertionSortOP (Optimized) Ascending: " + Arrays.toString(arrOPAsc));

        // Descending order
        int[] arrOPDesc = Arrays.copyOf(arr, arr.length);
        insertionSortOP.insertionSortOPDesc(arrOPDesc);
        System.out.println("InsertionSortOP (Optimized) Descending: " + Arrays.toString(arrOPDesc));
    }
}
