package insertion_sort;

/**
 *
 * @author dilakshi
 */
public class Insertion_Sort {

    // Method for ascending order using swap
    public void insertionSortAsc(int[] arr) {
        for (int i = 1; i < arr.length; i++) {
            for (int j = i; j > 0 && arr[j - 1] > arr[j]; j--) {
                // Swap elements if they are out of order
                int temp = arr[j];
                arr[j] = arr[j - 1];
                arr[j - 1] = temp;
            }
        }
    }

    // Method for descending order using swap
    public void insertionSortDesc(int[] arr) {
        for (int i = 1; i < arr.length; i++) {
            for (int j = i; j > 0 && arr[j - 1] < arr[j]; j--) {
                // Swap elements if they are out of order
                int temp = arr[j];
                arr[j] = arr[j - 1];
                arr[j - 1] = temp;
            }
        }
    }
}
