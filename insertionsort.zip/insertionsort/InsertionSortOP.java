package insertion_sort;

public class InsertionSortOP {

    // Optimized insertion sort for ascending order (replacement method)
    public void insertionSortOPAsc(int[] arr) {
        for (int i = 1; i < arr.length; i++) {
            int current = arr[i];
            int j = i - 1;
            // Shift elements until the correct position is found
            while (j >= 0 && arr[j] > current) {
                arr[j + 1] = arr[j];
                j--;
            }
            arr[j + 1] = current;
        }
    }

    // Optimized insertion sort for descending order (replacement method)
    public void insertionSortOPDesc(int[] arr) {
        for (int i = 1; i < arr.length; i++) {
            int current = arr[i];
            int j = i - 1;
            // Shift elements until the correct position is found
            while (j >= 0 && arr[j] < current) {
                arr[j + 1] = arr[j];
                j--;
            }
            arr[j + 1] = current;
        }
    }
}
